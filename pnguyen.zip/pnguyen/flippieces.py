import draw_board


dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8}


def ExistsOnBoard(x, y):
    return x >= 0 and x <= 7 and y >= 0 and y <=7


def Flip_Pieces(pos, player_variable):
    if player_variable == 'W':
        enemy_variable = 'B'
    else:
        enemy_variable = 'W'
    flip_list = []
    lst = []
    i = pos[0]
    j = pos[1]
    draw_board.board_game[i][j] = player_variable
    if draw_board.board_game[i][j] == player_variable:
        for xdirection, ydirection in [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]:
            x = i
            y = j
            x += xdirection
            y += ydirection
            print(x, y)
            if ExistsOnBoard(x, y) and draw_board.board_game[x][y] == enemy_variable:
                lst.append([x, y])
                x += xdirection
                y += ydirection
                if not ExistsOnBoard(x,y):
                    continue
                while draw_board.board_game[x][y]  == enemy_variable:
                    lst.append([x,y])
                    x += xdirection
                    y += ydirection
                    if not ExistsOnBoard(x, y):
                        break
                    if draw_board.board_game[x][y] == player_variable:
                        flip_list = lst
                if not ExistsOnBoard(x,y):
                    continue
    for i in flip_list:
        x = i[0]
        y = i[1]
        draw_board.board_game[x][y] = player_variable
    draw_board.draw_board()

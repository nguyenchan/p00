### Team Name: pnguyen+nhung

## Working Hours:
		* pnguyen : 10 hours
		* nhung : 9 hours
## How often we will check the code with each other:
		30 minutes
## Strengths and weakness:
		Strengths:
			pnguyen:
			nhung:
		Weakness:
			pnguyen:
			nhung:
## Allocation of workload:
		50/50
## Strategy so that everybody understands the code base:
		We will use comment for every block of code that we write.

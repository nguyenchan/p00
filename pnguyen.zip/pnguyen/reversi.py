import check_valid_move
import flippieces
import draw_board

player_w_lst = check_valid_move.check_valid_move('W')
player_b_lst = check_valid_move.check_valid_move('B')
player_b_score = 0
player_v_score = 0
player_turn = 0

dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8}


draw_board.draw_board()


def get_input(player_variable, valid):  # get move position from player's input
    move = input("Player " + player_variable + ": ")
    pos = list(move)  # split chars in string move to [move[0], move[1]]
    print(pos)
    pos[0] = dic[pos[0]]
    pos[1] = int(pos[1])  # cast to int to return integer position for later on

    if pos in valid:
        return pos


while player_b_lst != [] or player_w_lst != []: #while board is not full
    if player_turn == 0:
        player_variable = 'B'
        valid = check_valid_move.check_valid_move(player_variable)
        if len(valid) > 0:
            print("Valid choices: " + " ".join(valid))
            position = get_input(player_variable, valid)
            flippieces.Flip_Pieces(position, player_variable)
            continue
        else:
            print("Player " + player_variable + " cannot play.")
        player_b_lst = valid
        player_turn = 1

    if player_turn == 1:
        player_variable = 'W'
        valid = check_valid_move.check_valid_move(player_variable)
        if len(valid) > 0:
            print(" ".join(valid))
            position = get_input(player_variable, valid)
            flippieces.Flip_Pieces(position, player_variable)
            continue
        else:
            print("Player " + player_variable + " cannot play.")
        player_w_lst = valid
        player_turn = 0

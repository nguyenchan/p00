import draw_board


dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8}


def ExistsOnBoard(x, y):
    return x >= 0 and x <= 7 and y >= 0 and y <=7


def check_valid_move(player_variable): #get a list of all possible valid moves
    if player_variable == 'W':
        enemy_variable = 'B'
    else:
        enemy_variable = 'W'
    move_list = []
    move_list_str = []
    for i in range(8):
        for j in range(8):
            if draw_board.board_game[i][j] == player_variable:
                for xdirection, ydirection in [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]:
                    x = i
                    y = j
                    x += xdirection
                    y += ydirection
                    if ExistsOnBoard(x, y) and draw_board.board_game[x][y] == enemy_variable:
                        x += xdirection
                        y += ydirection
                        if draw_board.board_game[x][y] == '.':
                            move_list.append([x+1 ,y+1])
                            for k, v in dic.items():
                                if v == x:
                                    move_list_str.append(k + str(y+1))
                        if not ExistsOnBoard(x,y):
                            continue
                        while draw_board.board_game[x][y]  == enemy_variable:
                            x += xdirection
                            y += ydirection
                            if not ExistsOnBoard(x, y):
                                break
                            if draw_board.board_game[x][y] == '.':
                                move_list.append([x+1 ,y+1])
                                for k, v in dic.items():
                                    if v == x:
                                        move_list_str.append(k + str(y+1))
                        if not ExistsOnBoard(x,y):
                            continue
    return move_list_str
